import 'dart:convert';
import 'package:http/http.dart' as http;

class MusicService {
  static const String baseUrl = "https://deezerdevs-deezer.p.rapidapi.com/search";
  static const String apiKey = "5b89b6f9a0msh572f3f702c650ddp1be7fcjsn13579ba4b051"; // Replace with your key

  static Future<List<dynamic>> fetchSongs(String query) async {
    final response = await http.get(
      Uri.parse("$baseUrl?q=$query"),
      headers: {
        "X-RapidAPI-Key": apiKey,
        "X-RapidAPI-Host": "deezerdevs-deezer.p.rapidapi.com"
      },
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data["data"];
    } else {
      throw Exception("Failed to load songs");
    }
  }
}
