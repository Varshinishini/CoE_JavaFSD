import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../screens/song_details_screen.dart';

class FavoritesScreen extends StatelessWidget {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Favorite Songs ❤️")),
      body: StreamBuilder(
        stream: _firestore.collection("favorites").snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text("No favorite songs yet!"));
          }

          var favoriteSongs = snapshot.data!.docs;

          return ListView.builder(
            itemCount: favoriteSongs.length,
            itemBuilder: (context, index) {
              var song = favoriteSongs[index];

              return Card(
                child: ListTile(
                  leading: Image.network(song["albumCover"]),
                  title: Text(song["title"]),
                  subtitle: Text(song["artist"]),
                  trailing: IconButton(
                    icon: Icon(Icons.delete, color: Colors.red),
                    onPressed: () {
                      _firestore.collection("favorites").doc(song.id).delete();
                    },
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SongDetailsScreen(songData: song.data() as Map<String, dynamic>),
                      ),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}

