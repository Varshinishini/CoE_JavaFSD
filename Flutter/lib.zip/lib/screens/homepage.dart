import 'package:firebase_core/firebase_core.dart' show Firebase;
import 'package:flutter/material.dart';
import '../services/music_service.dart'; // Import API service
import '../widgets/song_card.dart';
import 'search_screen.dart'; // Import Search Screen

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<String> musicQuotes = [
    "Music is the universal language of mankind. - Henry Wadsworth Longfellow",
    "One good thing about music, when it hits you, you feel no pain. - Bob Marley",
    "Where words fail, music speaks. - Hans Christian Andersen",
    "Without music, life would be a mistake. - Friedrich Nietzsche",
    "Music expresses that which cannot be said and on which it is impossible to be silent. - Victor Hugo"
  ];

  final List<String> genres = ["Pop", "Rock", "Hip-Hop", "Jazz", "Classical"];
  
  String selectedGenre = ""; // Stores selected genre
  List<dynamic> songs = []; // Stores fetched songs

  Future<void> checkFirebase() async {
  try {
    await Firebase.initializeApp();
    print("✅ Firebase Initialized Successfully");
  } catch (e) {
    print("❌ Firebase Initialization Error: $e");
  }
}

@override
void initState() {
  super.initState();
  checkFirebase();
}

  void _fetchSongsByGenre(String genre) async {
    try {
      final data = await MusicService.fetchSongs(genre);
      setState(() {
        selectedGenre = genre;
        songs = data;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error fetching songs for $genre")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Melodify 🎶")),
      body: Column(
        children: [
          // Display a random quote
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              (musicQuotes..shuffle()).first, // Random quote
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, fontStyle: FontStyle.italic),
            ),
          ),

          SizedBox(height: 10),

          // Genre Selection Buttons
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: genres.map((genre) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5.0),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: selectedGenre == genre ? Colors.blueGrey : Colors.blue,
                    ),
                    onPressed: () => _fetchSongsByGenre(genre),
                    child: Text(genre),
                  ),
                );
              }).toList(),
            ),
          ),

          SizedBox(height: 20),

          // Navigate to Search Page
          ElevatedButton(
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SearchScreen()),
              );
            },
            child: Text("Search Songs 🎵"),
          ),

          SizedBox(height: 20),

          // Display Songs based on Selected Genre
          Expanded(
            child: songs.isEmpty
                ? Center(child: Text("Select a genre to see top songs"))
                : ListView.builder(
                    itemCount: songs.length,
                    itemBuilder: (context, index) {
                      return SongCard(songData: songs[index]);
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
