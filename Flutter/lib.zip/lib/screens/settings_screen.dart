import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/locale_provider.dart';
import '../providers/theme_provider.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final localeProvider = Provider.of<LocaleProvider>(context);
    final appLocalizations = AppLocalizations.of(context)!; // Get localized strings

    // Supported Locales
    final List<Locale> supportedLocales = [
      const Locale('en', 'US'),
      const Locale('ta', 'IN'),
      const Locale('hi', 'IN'),
    ];

    // Ensure the selected locale is valid
    Locale selectedLocale = supportedLocales.contains(localeProvider.locale)
        ? localeProvider.locale
        : supportedLocales.first;

    return Scaffold(
      appBar: AppBar(title: Text(appLocalizations.settingsTitle)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Dark Mode Toggle
            ListTile(
              title: Text(appLocalizations.darkMode),
              trailing: Switch(
                value: themeProvider.isDarkMode,
                onChanged: (value) => themeProvider.toggleTheme(),
              ),
            ),
            const Divider(),

            // Language Selection Dropdown
            ListTile(
              title: Text(appLocalizations.selectLanguage),
              trailing: DropdownButton<Locale>(
                value: selectedLocale, // Ensure a valid value is set
                onChanged: (Locale? newLocale) {
                  if (newLocale != null) {
                    localeProvider.setLocale(newLocale);
                  }
                },
                items: supportedLocales.map((Locale locale) {
                  return DropdownMenuItem<Locale>(
                    value: locale,
                    child: Text(_getLanguageName(locale)),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper function to get the language name
  String _getLanguageName(Locale locale) {
    switch (locale.languageCode) {
      case 'en':
        return 'English';
      case 'ta':
        return 'தமிழ்';
      case 'hi':
        return 'हिन्दी';
      default:
        return 'Unknown';
    }
  }
}
