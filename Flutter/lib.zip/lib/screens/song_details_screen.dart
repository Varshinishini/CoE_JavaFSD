import 'package:flutter/material.dart';

class SongDetailsScreen extends StatelessWidget {
  final Map<String, dynamic> songData;

  SongDetailsScreen({required this.songData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(songData["title"])),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Image.network(songData["album"]["cover_big"]),
            SizedBox(height: 10),
            Text(songData["title"], style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            Text("Artist: ${songData["artist"]["name"]}", style: TextStyle(fontSize: 18)),
            Text("Album: ${songData["album"]["title"]}", style: TextStyle(fontSize: 16)),
            SizedBox(height: 20),
            ElevatedButton.icon(
              icon: Icon(Icons.play_arrow),
              label: Text("Play Preview"),
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Playing: ${songData["title"]}")),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
