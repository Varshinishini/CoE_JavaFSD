import 'package:flutter/material.dart';
import '../services/music_service.dart';
import '../widgets/song_card.dart';

class SearchScreen extends StatefulWidget {
  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _controller = TextEditingController();
  String _query = "Eminem"; // Default search query
  List<dynamic> _songs = [];

  void _fetchSongs() async {
    try {
      final data = await MusicService.fetchSongs(_query);
      setState(() {
        _songs = data;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error fetching data")),
      );
    }
  }

  @override
  void initState() {
    super.initState();
    _fetchSongs();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Melodify 🎵")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              style: TextStyle(color: Colors.black), // Black text color
              decoration: InputDecoration(
                labelText: "Search for a song",
                labelStyle: TextStyle(color: Colors.black54), // Light black label
                filled: true,
                fillColor: Colors.white, // White background
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10), // Rounded corners
                  borderSide: BorderSide(color: Colors.black), // Black border
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.black38),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.black, width: 2),
                ),
                suffixIcon: IconButton(
                  icon: Icon(Icons.search, color: Colors.black), // Black search icon
                  onPressed: () {
                    setState(() {
                      _query = _controller.text;
                    });
                    _fetchSongs();
                  },
                ),
              ),
            ),
            SizedBox(height: 20),
            _songs.isEmpty
                ? CircularProgressIndicator()
                : Expanded(
                    child: ListView.builder(
                      itemCount: _songs.length,
                      itemBuilder: (context, index) {
                        return SongCard(songData: _songs[index]);
                      },
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
