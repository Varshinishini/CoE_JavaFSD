import 'package:flutter/material.dart';

class AppTheme {
  // Light Theme (if needed)
  static final lightTheme = ThemeData(
    brightness: Brightness.light,
    primaryColor: Color.fromARGB(255, 0, 173, 179),
    scaffoldBackgroundColor: Colors.white,
    appBarTheme: AppBarTheme(
      backgroundColor: Color.fromARGB(255, 0, 179, 179), 
      foregroundColor: Colors.white, 
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: Colors.white,
      selectedItemColor: Color.fromARGB(255, 0, 149, 179),
      unselectedItemColor: Colors.grey,
    ),
  );

  // Dark Theme (Main Theme for Music Finder)
  static final darkTheme = ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: Color(0xFF121212), // Background
    primaryColor: Color(0xFFBB86FC), // Neon Purple
    appBarTheme: AppBarTheme(
      backgroundColor: Color.fromARGB(255, 0, 158, 179), // Dark Purple
      foregroundColor: Colors.white,
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: Color(0xFF121212), // Black background
      selectedItemColor: Color(0xFFBB86FC), // Neon Purple for active item
      unselectedItemColor: Color(0xFFA0A0A0), // Muted Gray for inactive items
    ),
    iconTheme: IconThemeData(
      color: Color(0xFF03DAC5), // Cyan icons
    ),
    textTheme: TextTheme(
      bodyLarge: TextStyle(color: Colors.white),
      bodyMedium: TextStyle(color: Color(0xFFA0A0A0)), // Muted gray text
    ),
  );
}
