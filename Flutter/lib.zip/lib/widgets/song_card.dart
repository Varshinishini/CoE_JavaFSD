import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../screens/song_details_screen.dart';

class SongCard extends StatefulWidget {
  final Map<String, dynamic> songData;

  SongCard({required this.songData});

  @override
  _SongCardState createState() => _SongCardState();
}

class _SongCardState extends State<SongCard> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  bool isFavorite = false;

  @override
  void initState() {
    super.initState();
    _checkFavoriteStatus();
  }

  // Check if the song is already in favorites
  void _checkFavoriteStatus() async {
    var doc = await _firestore.collection("favorites").doc(widget.songData['id'].toString()).get();
    setState(() {
      isFavorite = doc.exists;
    });
  }

  // Toggle favorite status
  void _toggleFavorite() async {
    if (isFavorite) {
      await _firestore.collection("favorites").doc(widget.songData['id'].toString()).delete();
    } else {
      await _firestore.collection("favorites").doc(widget.songData['id'].toString()).set({
        "id": widget.songData['id'],
        "title": widget.songData['title'],
        "artist": widget.songData['artist']['name'],
        "albumCover": widget.songData['album']['cover_medium'],
      });
    }
    setState(() {
      isFavorite = !isFavorite;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Image.network(widget.songData["album"]["cover_medium"]),
        title: Text(widget.songData["title"]),
        subtitle: Text(widget.songData["artist"]["name"]),
        trailing: IconButton(
          icon: Icon(
            isFavorite ? Icons.favorite : Icons.favorite_border,
            color: isFavorite ? Colors.pink : Colors.grey,
          ),
          onPressed: _toggleFavorite,
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SongDetailsScreen(songData: widget.songData),
            ),
          );
        },
      ),
    );
  }
}
