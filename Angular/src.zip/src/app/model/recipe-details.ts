export interface RecipeDetails {
    name: string;
    category: string;
    image: string;
    ingredients: string[];
    instructions: string[];
    cookingTime: string;
    servings: number;
  }
  