export interface HomeContent {
    title: string;
    subtitle: string;
    description: string;
    bannerImage: string;
  }
  
  export interface Recipe {
    id: number;
    name: string;
    description: string;
    image: string;
  }
  
  export interface Category {
    id: number;
    name: string;
    image: string;
  }
  
  export interface Testimonial {
    id: number;
    user: string;
    feedback: string;
    image: string;
  }
  