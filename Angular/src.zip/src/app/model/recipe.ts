export interface Recipe {
    id: string;
    name: string;
    category: string;
    image: string;
    shortDescription: string;
    cookingTime: string;
  }
  
  export interface RecipeDetails extends Recipe {
    ingredients: string[];
    instructions: string[];
    servings: number;
  }
  
  