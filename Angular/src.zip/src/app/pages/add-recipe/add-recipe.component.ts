import { Component } from '@angular/core';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-add-recipe',
  templateUrl: './add-recipe.component.html',
  styleUrls: ['./add-recipe.component.css']
})
export class AddRecipeComponent {
  newRecipe = {
    name: '',
    category: '',
    image: '',
    shortDescription: '',
    cookingTime: '',
    ingredients: '',
    instructions: '',
    servings: null
  };

  constructor(private apiService: ApiService) {}

  // onFileSelected(event: any) {
  //   const file = event.target.files[0]; // Get selected file
  //   if (file) {
  //     const reader = new FileReader();
  //     reader.onload = (e: any) => {
  //       this.newRecipe.image = e.target.result; // Store Base64 string
  //     };
  //     reader.readAsDataURL(file);
  //   }
  // }
  onFileSelected(event: any) {
    const file = event.target.files[0]; // Get the selected file
    if (file) {
      this.newRecipe.image = file.name; // Store only the filename
    }
  }

  addRecipe() {
    if (!this.newRecipe.name || !this.newRecipe.category || !this.newRecipe.image) {
      alert("Please fill all fields!");
      return;
    }


    

    const recipeId = Math.floor(Math.random() * 1000).toString(); // Generate a unique ID

    // Create objects for recipes and recipe-details
    const recipeEntry = {
      id: recipeId,
      name: this.newRecipe.name,
      category: this.newRecipe.category,
      image: this.newRecipe.image,
      shortDescription: this.newRecipe.shortDescription,
      cookingTime: this.newRecipe.cookingTime
    };

    const recipeDetailEntry = {
      id: recipeId,
      name: this.newRecipe.name,
      category: this.newRecipe.category,
      image: this.newRecipe.image,
      ingredients: this.newRecipe.ingredients.split(',').map(item => item.trim()),
      instructions: this.newRecipe.instructions.split(',').map(item => item.trim()),
      cookingTime: this.newRecipe.cookingTime,
      servings: this.newRecipe.servings
    };

    // Call the API service to add to json
    this.apiService.addRecipe(recipeEntry, recipeDetailEntry).subscribe(() => {
      alert("Recipe added successfully!");
      this.newRecipe = { name: '', category: '', image: '', shortDescription: '', cookingTime: '', ingredients: '', instructions: '', servings: null };
    });
  }
}
