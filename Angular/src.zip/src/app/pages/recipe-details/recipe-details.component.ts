import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { RecipeDetails } from '../../model/recipe-details';

@Component({
  selector: 'app-recipe-details',
  templateUrl: './recipe-details.component.html',
  styleUrls: ['./recipe-details.component.css']
})
export class RecipeDetailsComponent implements OnInit {
  recipe!: RecipeDetails;

  constructor(private route: ActivatedRoute, private apiService: ApiService) {}

  ngOnInit() {
    const recipeId = this.route.snapshot.paramMap.get('id'); // Get ID from URL

    if (recipeId) {
      this.apiService.getRecipeDetails(recipeId).subscribe(data => {
        this.recipe = data;
      });
    }
  }

  
}
