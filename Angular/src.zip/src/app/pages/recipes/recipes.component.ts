import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Recipe } from '../../model/recipe';

@Component({
  selector: 'app-recipes',
  templateUrl: './recipes.component.html',
  styleUrls: ['./recipes.component.css']
})
export class RecipesComponent implements OnInit {
  recipes: Recipe[] = [];

  categoryTypes: string[] = [
    'All',
   'Italian',
   'Indian',
   'Dessert',
   'Salad',
   'Breakfast',
   'Mexican'
   ];
  selected:string = 'All'

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.fetchRecipes();
  }

  fetchRecipes(): void {
    this.apiService.getRecipes().subscribe((data: Recipe[]) => {
      this.recipes = data;
    });
  }

  addToFavorites(recipe: any) {
    this.apiService.addToFavorites(recipe).subscribe(() => {
      alert(`${recipe.name} added to favorites!`);
    }, error => {
      console.error('Error adding to favorites:', error);
      alert('Failed to add to favorites.');
    });
  }
  
}

