import { Component, ElementRef, ViewChild, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service'; // Import your API service

@Component({
  selector: 'app-favorites',
  templateUrl: './favorites.component.html',
  styleUrls: ['./favorites.component.css']
})
export class FavoritesComponent implements OnInit {
  @ViewChild('scrollableContainer', { static: false }) scrollableContainer!: ElementRef;

  favoriteRecipes: any[] = []; // Store API data

  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.fetchFavorites();
  }

  fetchFavorites() {
    this.apiService.getFavorites().subscribe((data: any[]) => {
      this.favoriteRecipes = data; // Assign API data to favoriteRecipes
    });
  }

  removeFromFavorites(id: number) {
    this.favoriteRecipes = this.favoriteRecipes.filter(recipe => recipe.id !== id);
    this.apiService.removeFromFavorites(id).subscribe(); // Remove from API.json
  }

  scrollLeft() {
    this.scrollableContainer.nativeElement.scrollBy({ left: -300, behavior: 'smooth' });
  }

  scrollRight() {
    this.scrollableContainer.nativeElement.scrollBy({ left: 300, behavior: 'smooth' });
  }
}
