import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { RecipesComponent } from './pages/recipes/recipes.component';
import { AddRecipeComponent } from './pages/add-recipe/add-recipe.component';
import { FavoritesComponent } from './pages/favorites/favorites.component';
import { RecipeDetailsComponent } from './pages/recipe-details/recipe-details.component';
import { LoginComponent } from './common/login/login.component';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
    { path: '', component: HomeComponent }, // Default route
    { path: 'home', component: HomeComponent },
    { path: 'recipes', component: RecipesComponent },
    { path: 'add-recipe', component: AddRecipeComponent, canActivate: [AuthGuard] },
    { path: 'favorites', component: FavoritesComponent },
    { path: 'recipes', component: RecipesComponent },
    {path:'login',component:LoginComponent},
    { path: 'recipe-details/:id', component: RecipeDetailsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
