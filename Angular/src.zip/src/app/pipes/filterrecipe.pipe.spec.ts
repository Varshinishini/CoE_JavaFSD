import { FilterrecipePipe } from './filterrecipe.pipe';

describe('FilterrecipePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterrecipePipe();
    expect(pipe).toBeTruthy();
  });
});
