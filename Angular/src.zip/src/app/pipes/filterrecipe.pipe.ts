import { Pipe, PipeTransform } from '@angular/core';
 import { Recipe } from '../model/recipe';
 
 @Pipe({
   name: 'filterrecipe'
 })
 export class FilterrecipePipe implements PipeTransform {
 
   transform(recipes: Recipe[], category:string): Recipe[] {
     if(category === 'All') 
       return recipes;
     
     return recipes.filter(Recipe => Recipe.category === category);
   }
 
 }
