// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrl: './app.component.css'
// })
// export class AppComponent {
//   title = 'recipe-management';
// }


import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CookCraft';

  // constructor(private router: Router) {}

  // // Featured recipes (Dummy Data)
  // featuredRecipes = [
  //   { id: 1, name: 'Chocolate Cake', image: 'recipe1.jpg', category: 'Dessert' },
  //   { id: 2, name: 'Pasta Alfredo', image: 'recipe2.jpg', category: 'Main Course' },
  //   { id: 3, name: 'Mango Smoothie', image: 'recipe3.jpg', category: 'Beverage' }
  // ];

featuredRecipes: any[]=[];
isHome: boolean = false;
homeRendered: boolean = false; 
  constructor(private router: Router) {
    this.featuredRecipes = [
      { id: 1, name: 'Chocolate Cake', image: 'recipe1.jpg', category: 'Dessert' },
      { id: 2, name: 'Pasta Alfredo', image: 'recipe2.jpg', category: 'Main Course' },
      { id: 3, name: 'Mango Smoothie', image: 'recipe3.jpg', category: 'Beverage' }
    ];
  }
  ngOnInit() {
    this.isHome = this.isHomePage();
    if (this.isHome) {
      this.homeRendered = true;
    }
  }



  favorites: any[] = [];

  // Handles "Add to Favorites" event from Home component
  addToFavorites(recipe: any) {
    if (!this.favorites.find(r => r.id === recipe.id)) {
      this.favorites.push(recipe);
      alert(`${recipe.name} added to favorites!`);
    } else {
      alert(`${recipe.name} is already in favorites!`);
    }
  }

  isHomePage(): boolean {
    return this.router.url === '/';
  }
}

