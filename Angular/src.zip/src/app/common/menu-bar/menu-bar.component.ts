import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu-bar',
  templateUrl: './menu-bar.component.html',
  styleUrls: ['./menu-bar.component.css']
})
export class MenuBarComponent {
  status: boolean = false;
  loginmenu: string = "Login";

  constructor(private router: Router) {
    this.checkLoginStatus();
  }

  checkLoginStatus() {
    let username = localStorage.getItem("username");
    if (username) {
      this.status = true;
      this.loginmenu = ` Logout`;
    }
  }

  loginhandler() {
    if (this.status) {
      localStorage.removeItem("username"); // ❌ Logout user
      this.status = false;
      this.loginmenu = "Login";
      this.router.navigate(['/home']); // ✅ Redirect to home after logout
    } else {
      this.router.navigate(['/login']); // ✅ Go to login page
    }
  }
}
