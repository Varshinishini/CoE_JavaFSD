import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Recipe } from '../model/recipe';


@Injectable({
  providedIn: 'root'
})
export class ApiService {
  //private apiUrl = 'api.json';  // Change if needed
  private apiUrl = 'http://localhost:4500';

  constructor(private http: HttpClient) {}

  //getData(): Observable<any> {
  //  return this.http.get<any>(this.apiUrl);
  //}

  

  getRecipes(): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:4500/recipes');
  }

  

  

  getRecipeDetails(id: string): Observable<any> {
    return this.http.get<any>(`http://localhost:4500/recipe-details/${id}`);
  }

  addToFavorites(recipe: any): Observable<any> {
    return this.http.post('http://localhost:4500/favorites', recipe);
  }

  getFavorites(): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:4500/favorites');
  }

  removeFromFavorites(id: number): Observable<any> {
    return this.http.delete(`http://localhost:4500/favorites/${id}`);
  }

  // addRecipe(recipe: any, recipeDetail: any): Observable<any> {
  //   return new Observable(observer => {
  //     this.getRecipes().subscribe((data: any) => {
  //       data.recipes.push(recipe);
  //       data['recipe-details'].push(recipeDetail);
  //       observer.next(data);
  //       observer.complete();
  //     });
  //   });
  // }
  addRecipe(recipe: any, recipeDetail: any): Observable<any> {
    return new Observable(observer => {
      this.http.post(`${this.apiUrl}/recipes`, recipe).subscribe({
        next: (res) => {
          this.http.post(`${this.apiUrl}/recipe-details`, recipeDetail).subscribe({
            next: (detailRes) => {
              observer.next({ recipe: res, recipeDetail: detailRes });
              observer.complete();
            },
            error: (err) => observer.error(err)
          });
        },
        error: (err) => observer.error(err)
      });
    });
  }

  
}

